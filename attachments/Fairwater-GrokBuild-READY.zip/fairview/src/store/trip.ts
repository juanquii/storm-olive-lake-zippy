import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Band, RegionId } from "@/lib/marine/types";

export type ChartView = "chart" | "satellite" | "hybrid" | "fishing";

type TripState = {
  groundId: string;
  region: RegionId | "all";
  band: Band | "all";
  dayOffset: 0 | 1 | 2;
  chartOn: boolean;
  chartView: ChartView;
  saved: string[];
  setGround: (id: string) => void;
  setRegion: (region: RegionId | "all") => void;
  setBand: (band: Band | "all") => void;
  setDayOffset: (dayOffset: 0 | 1 | 2) => void;
  setChartView: (chartView: ChartView) => void;
  toggleChart: () => void;
  toggleSaved: (id: string) => void;
};

export const useTrip = create<TripState>()(
  persist(
    (set) => ({
      groundId: "beaufort-inlet",
      region: "outer-banks",
      band: "all",
      dayOffset: 0,
      chartOn: false,
      chartView: "chart",
      saved: [],
      setGround: (groundId) => set({ groundId }),
      setRegion: (region) => set({ region }),
      setBand: (band) => set({ band }),
      setDayOffset: (dayOffset) => set({ dayOffset }),
      setChartView: (chartView) => set({ chartView }),
      toggleChart: () => set((s) => ({ chartOn: !s.chartOn })),
      toggleSaved: (id) =>
        set((s) => ({
          saved: s.saved.includes(id) ? s.saved.filter((x) => x !== id) : [...s.saved, id],
        })),
    }),
    {
      name: "fairwater",
      skipHydration: true,
      version: 3,
      migrate: (persisted) => {
        const state = (persisted ?? {}) as { region?: string; groundId?: string };
        return { ...state, region: "outer-banks" as const, groundId: "beaufort-inlet" };
      },
    },
  ),
);
