import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Waypoint = { id: string; name: string; lat: number; lng: number };
export type TrackPoint = { lat: number; lng: number };
export type CatchLog = {
  id: string;
  species: string;
  at: string;
  lat: number;
  lng: number;
  tide: string;
  moon: string;
};

/** Sportsman Open 262 · twin ~F200 · ~22" draft · ~150–182 gal usable tank. */
export const SPORTSMAN_262 = {
  boatLabel: "Sportsman Open 262",
  draftFt: 1.83,
  cruiseKt: 28,
  burnGph: 15,  // twin F200 cruise ~planning (~2.1 mpg @ ~28 kt); bump for rough seas
  tankGal: 170,
  reservePct: 25,
  maxSeasFt: 3.5,
  minPeriodS: 6,
  maxWindMph: 18,
} as const;

/** One-way offshore planning leg (nm). planFuelNm doubles this for round-trip. Juan: 40 out / 80 RT. */
export const OFFSHORE_ONE_WAY_NM = 40;
/** @deprecated alias — prefer OFFSHORE_ONE_WAY_NM */
export const OFFSHORE_RT_NM = OFFSHORE_ONE_WAY_NM;

export const CHECKLIST_ITEMS: { id: string; label: string }[] = [
  { id: "gate", label: "Inlet gate reviewed (seas, period, wind, ebb)" },
  { id: "nws", label: "NWS coastal waters (AMZ158) read" },
  { id: "fuel", label: "Fuel topped for 40 nm out / 80 nm RT + reserve" },
  { id: "float", label: "Float plan shared (ETA, crew, VHF)" },
  { id: "vhf", label: "VHF radio check + channels 16/22A" },
  { id: "safety", label: "PFDs, throwables, flares, first aid" },
  { id: "kill", label: "Kill-switch lanyard + engine pre-start" },
  { id: "phone", label: "Phone charged · Fairwater offline tiles saved" },
];

type RuleKeys =
  | "draftFt"
  | "cruiseKt"
  | "burnGph"
  | "tankGal"
  | "reservePct"
  | "maxSeasFt"
  | "minPeriodS"
  | "maxWindMph";

type BoatState = {
  boatLabel: string;
  draftFt: number;
  cruiseKt: number;
  burnGph: number;
  tankGal: number;
  reservePct: number;
  maxSeasFt: number;
  minPeriodS: number;
  maxWindMph: number;
  waypoints: Waypoint[];
  track: TrackPoint[];
  recording: boolean;
  markMode: boolean;
  catches: CatchLog[];
  checklist: Record<string, boolean>;
  nightHelm: boolean;
  setRule: (patch: Partial<Pick<BoatState, RuleKeys>>) => void;
  applySportsman262: () => void;
  addWaypoint: (lat: number, lng: number) => void;
  clearWaypoints: () => void;
  toggleMark: () => void;
  setRecording: (recording: boolean) => void;
  addTrack: (point: TrackPoint) => void;
  clearTrack: () => void;
  addCatch: (entry: Omit<CatchLog, "id">) => void;
  toggleCheck: (id: string) => void;
  resetChecklist: () => void;
  setNightHelm: (nightHelm: boolean) => void;
};

function emptyChecklist(): Record<string, boolean> {
  return Object.fromEntries(CHECKLIST_ITEMS.map((item) => [item.id, false]));
}

/** Replace legacy bay-boat defaults (40 gal / 1.5 ft / 8 gph) with Sportsman 262. */
function migrateBoat(persisted: unknown): BoatState {
  const state = (persisted ?? {}) as Partial<BoatState> & { tankGal?: number; draftFt?: number; burnGph?: number };
  const looksLegacy =
    state.tankGal === 40 ||
    state.draftFt === 1.5 ||
    state.burnGph === 8 ||
    state.burnGph === 24 ||
    state.tankGal == null;
  const next = {
    ...SPORTSMAN_262,
    ...state,
    boatLabel: looksLegacy ? SPORTSMAN_262.boatLabel : (state.boatLabel ?? SPORTSMAN_262.boatLabel),
    draftFt: looksLegacy ? SPORTSMAN_262.draftFt : (state.draftFt ?? SPORTSMAN_262.draftFt),
    cruiseKt: looksLegacy ? SPORTSMAN_262.cruiseKt : (state.cruiseKt ?? SPORTSMAN_262.cruiseKt),
    burnGph: looksLegacy ? SPORTSMAN_262.burnGph : (state.burnGph ?? SPORTSMAN_262.burnGph),
    tankGal: looksLegacy ? SPORTSMAN_262.tankGal : (state.tankGal ?? SPORTSMAN_262.tankGal),
    reservePct: looksLegacy ? SPORTSMAN_262.reservePct : (state.reservePct ?? SPORTSMAN_262.reservePct),
    maxSeasFt: looksLegacy ? SPORTSMAN_262.maxSeasFt : (state.maxSeasFt ?? SPORTSMAN_262.maxSeasFt),
    minPeriodS: state.minPeriodS ?? SPORTSMAN_262.minPeriodS,
    maxWindMph: state.maxWindMph ?? SPORTSMAN_262.maxWindMph,
    waypoints: state.waypoints ?? [],
    track: state.track ?? [],
    recording: false,
    markMode: false,
    catches: state.catches ?? [],
    checklist: { ...emptyChecklist(), ...(state.checklist ?? {}) },
    nightHelm: state.nightHelm ?? false,
  };
  return next as BoatState;
}

export function planFuelNm(
  nmOneWay: number,
  cruiseKt: number,
  burnGph: number,
  tankGal: number,
  reservePct: number,
) {
  const nm = nmOneWay * 2;
  const hours = nm / Math.max(cruiseKt, 1);
  const gallons = hours * burnGph;
  const usable = tankGal * (1 - reservePct / 100);
  return {
    nm,
    hours,
    gallons,
    usable,
    home: gallons <= usable,
    reserveGal: tankGal - usable,
  };
}

export const useBoat = create<BoatState>()(
  persist(
    (set) => ({
      ...SPORTSMAN_262,
      waypoints: [],
      track: [],
      recording: false,
      markMode: false,
      catches: [],
      checklist: emptyChecklist(),
      nightHelm: false,
      setRule: (patch) => set(patch),
      applySportsman262: () => set({ ...SPORTSMAN_262 }),
      addWaypoint: (lat, lng) =>
        set((s) => ({
          waypoints: [
            ...s.waypoints,
            { id: `${Date.now()}`, name: `Mark ${s.waypoints.length + 1}`, lat, lng },
          ].slice(-12),
        })),
      clearWaypoints: () => set({ waypoints: [] }),
      toggleMark: () => set((s) => ({ markMode: !s.markMode })),
      setRecording: (recording) => set({ recording }),
      addTrack: (point) =>
        set((s) => {
          const last = s.track[s.track.length - 1];
          if (last && Math.abs(last.lat - point.lat) < 0.00005 && Math.abs(last.lng - point.lng) < 0.00005) return s;
          return { track: [...s.track, point].slice(-400) };
        }),
      clearTrack: () => set({ track: [], recording: false }),
      addCatch: (entry) =>
        set((s) => ({ catches: [{ ...entry, id: `${Date.now()}` }, ...s.catches].slice(0, 20) })),
      toggleCheck: (id) =>
        set((s) => ({ checklist: { ...s.checklist, [id]: !s.checklist[id] } })),
      resetChecklist: () => set({ checklist: emptyChecklist() }),
      setNightHelm: (nightHelm) => set({ nightHelm }),
    }),
    {
      name: "fairwater-boat",
      skipHydration: true,
      version: 2,
      migrate: (persisted) => migrateBoat(persisted) as never,
    },
  ),
);
