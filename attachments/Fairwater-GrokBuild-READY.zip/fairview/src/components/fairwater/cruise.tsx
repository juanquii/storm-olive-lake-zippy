import { useEffect, useMemo, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { getBrief, type MarineBrief } from "@/lib/marine/brief";
import { getConditions, currentAt } from "@/lib/marine/conditions";
import { compass, clock } from "@/lib/marine/format";
import { inletGate, nwsWind } from "@/lib/marine/gate";
import { bearing, miles } from "@/lib/marine/geo";
import { moonInfo } from "@/lib/marine/moon";
import { sunTimes } from "@/lib/marine/sun";
import {
  CHECKLIST_ITEMS,
  OFFSHORE_RT_NM,
  planFuelNm,
  useBoat,
} from "@/store/boat";
import { cn } from "@/lib/cn";

const INLET = { lat: 34.68, lng: -76.66, stationId: "8656483", stationName: "Beaufort", distanceMi: 2 };

const DMF_PAGE =
  "https://www.deq.nc.gov/about/divisions/marine-fisheries/rules-proclamations-and-size-and-bag-limits/fisheries-management-proclamations";

const BRIEF_CACHE_KEY = "fairwater-brief-last";

type CachedBrief = { at: string; brief: MarineBrief };

function num(value: string, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function nearestWeather(
  rows: { time: string; windMph: number | null }[],
  t: number,
): { windMph: number | null } | null {
  let best: { windMph: number | null } | null = null;
  let gap = Infinity;
  for (const row of rows) {
    const delta = Math.abs(new Date(row.time).getTime() - t);
    if (delta < gap) {
      gap = delta;
      best = row;
    }
  }
  return best;
}

function routeFuel(
  marks: { lat: number; lng: number }[],
  cruiseKt: number,
  burnGph: number,
  tankGal: number,
  reservePct: number,
) {
  let statute = 0;
  for (let i = 1; i < marks.length; i++) {
    statute += miles(marks[i - 1].lat, marks[i - 1].lng, marks[i].lat, marks[i].lng);
  }
  const nm = statute * 0.868976;
  const hours = (nm / Math.max(cruiseKt, 1)) * 2;
  const gallons = hours * burnGph;
  const usable = tankGal * (1 - reservePct / 100);
  return { nm, hours, gallons, home: gallons <= usable };
}

function readCachedBrief(): CachedBrief | null {
  try {
    const raw = localStorage.getItem(BRIEF_CACHE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as CachedBrief;
  } catch {
    return null;
  }
}

function ageLabel(iso: string): string {
  const mins = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 48) return `${hrs}h ago`;
  return `${Math.round(hrs / 24)}d ago`;
}

function Fold({ title, meta, children, defaultOpen = false }: { title: string; meta?: string; children: ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section className="border-t border-line pt-1">
      <button
        type="button"
        className="flex min-h-12 w-full items-center justify-between gap-3 text-left"
        aria-expanded={open}
        onClick={() => setOpen((value) => !value)}
      >
        <span className="text-base font-medium text-fg">{title}</span>
        <span className="shrink-0 text-sm text-muted">
          {meta ? `${meta} · ` : ""}
          {open ? "Hide" : "Show"}
        </span>
      </button>
      {open ? <div className="pb-2">{children}</div> : null}
    </section>
  );
}

export function CruiseBoard() {
  const boat = useBoat();
  const [live, setLive] = useState(false);
  const [species, setSpecies] = useState("Speckled trout");
  const [cachedBrief, setCachedBrief] = useState<CachedBrief | null>(null);

  useEffect(() => {
    void useBoat.persist.rehydrate();
    setCachedBrief(readCachedBrief());
    setLive(true);
  }, []);

  const inlet = useQuery({
    queryKey: ["fairwater-inlet", "beaufort"],
    enabled: live,
    staleTime: 10 * 60 * 1000,
    queryFn: () => getConditions({ data: INLET }),
  });
  const brief = useQuery({
    queryKey: ["fairwater-brief"],
    enabled: live,
    staleTime: 20 * 60 * 1000,
    queryFn: () => getBrief(),
  });

  useEffect(() => {
    if (!brief.data) return;
    const payload: CachedBrief = { at: new Date().toISOString(), brief: brief.data };
    try {
      localStorage.setItem(BRIEF_CACHE_KEY, JSON.stringify(payload));
      setCachedBrief(payload);
    } catch {
      /* ignore quota */
    }
  }, [brief.data]);

  const displayBrief = brief.data ?? cachedBrief?.brief ?? null;
  const briefStale = !brief.data && !!cachedBrief?.brief;
  const briefAge = cachedBrief?.at ? ageLabel(cachedBrief.at) : null;

  const now = new Date();
  const flow = inlet.data ? currentAt(inlet.data.current, now.getTime()) : null;
  const buoy = inlet.data?.buoy ?? null;
  const weather = inlet.data?.weatherHourly.length ? nearestWeather(inlet.data.weatherHourly, now.getTime()) : null;
  const officialWind = nwsWind(displayBrief?.forecast ?? null);
  const windMph = weather?.windMph ?? buoy?.windMph ?? officialWind?.mph ?? null;
  const windText =
    weather?.windMph != null
      ? `${Math.round(weather.windMph)} mph · model`
      : buoy?.windMph != null
        ? `${Math.round(buoy.windMph)} mph · buoy`
        : officialWind
          ? officialWind.label
          : "—";
  const gate = inletGate({
    seasFt: buoy?.waveFt ?? null,
    periodS: buoy?.wavePeriodS ?? null,
    windMph,
    stage: flow?.stage ?? null,
    currentKt: flow?.speedKt ?? null,
    forecast: displayBrief?.forecast ?? null,
    rules: boat,
  });
  useEffect(() => {
    const label = gate.gate === "no-go" ? "No-go" : gate.gate === "caution" ? "Caution" : "Under your limits";
    window.dispatchEvent(new CustomEvent("fairwater-gate", { detail: label }));
  }, [gate.gate]);
  const sun = sunTimes(now, INLET.lat, INLET.lng);
  const route = routeFuel(boat.waypoints, boat.cruiseKt, boat.burnGph, boat.tankGal, boat.reservePct);
  const offshore = useMemo(
    () => planFuelNm(OFFSHORE_RT_NM, boat.cruiseKt, boat.burnGph, boat.tankGal, boat.reservePct),
    [boat.cruiseKt, boat.burnGph, boat.tankGal, boat.reservePct],
  );
  const checksDone = CHECKLIST_ITEMS.filter((item) => boat.checklist[item.id]).length;

  useEffect(() => {
    if (!boat.recording || !live) return;
    const id = navigator.geolocation.watchPosition(
      (pos) => boat.addTrack({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => boat.setRecording(false),
      { enableHighAccuracy: true, maximumAge: 5000 },
    );
    return () => navigator.geolocation.clearWatch(id);
  }, [boat.recording, live, boat.addTrack, boat.setRecording]);

  return (
    <div className="flex flex-col gap-5">
      <section
        className={cn(
          "rounded-xl border p-4",
          gate.gate === "no-go" && "border-poor",
          gate.gate === "caution" && "border-fair",
          gate.gate === "go" && "border-good",
        )}
      >
        <p className="text-xs font-medium tracking-wide text-subtle uppercase">Beaufort Inlet run</p>
        <p className="font-display text-4xl leading-none text-fg">
          {gate.gate === "no-go" ? "No-go" : gate.gate === "caution" ? "Caution" : "Under your limits"}
        </p>
        <p className="mt-2 text-sm text-muted">
          {boat.boatLabel} · draft {boat.draftFt.toFixed(2)} ft (~{Math.round(boat.draftFt * 12)}″) · not a navigation clearance
        </p>
        <ul className="mt-3 flex flex-col gap-1 text-sm text-fg">
          {gate.reasons.map((reason) => (
            <li key={reason}>{reason}</li>
          ))}
        </ul>
        <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
          <div>
            <dt className="text-subtle">Tide · NOAA</dt>
            <dd className="text-fg">{inlet.data?.tide ? inlet.data.tide.stationName : "Loading"}</dd>
          </div>
          <div>
            <dt className="text-subtle">Current · NOAA</dt>
            <dd className="text-fg">
              {flow && inlet.data?.current
                ? `${flow.stage} ${flow.speedKt.toFixed(1)} kt · ${inlet.data.current.stationName.split(",")[0]}`
                : "No station"}
            </dd>
          </div>
          <div>
            <dt className="text-subtle">Seas · NDBC</dt>
            <dd className="text-fg">
              {buoy
                ? `${buoy.waveFt.toFixed(1)} ft · ${buoy.wavePeriodS ? `${Math.round(buoy.wavePeriodS)} s` : "period n/a"}`
                : "No fresh buoy"}
            </dd>
          </div>
          <div>
            <dt className="text-subtle">Wind</dt>
            <dd className="text-fg">{windText}</dd>
          </div>
        </dl>
        {buoy ? (
          <p className="mt-3 text-sm text-fg">
            {buoy.id} is {buoy.name}. It sits {buoy.distanceMi} miles {compass(bearing(INLET.lat, INLET.lng, buoy.lat, buoy.lng))} of the inlet mouth, about{" "}
            {Math.round(buoy.distanceMi * 0.869)} nm. Nothing is moored in Beaufort Inlet. The bar can be rougher than this buoy.
          </p>
        ) : null}
        <p className="mt-2 text-sm text-muted">
          The dashed line offshore is an approximate 3 nm state-water line, not the legal boundary. The inlet is inside state water. This buoy is outside it.
        </p>
        {sun ? (
          <p className="mt-2 text-sm text-muted">
            Sun {clock(sun.rise)}–{clock(sun.set)}
          </p>
        ) : null}
        <div className="mt-3 grid grid-cols-3 gap-2">
          <Field label="Max seas" value={boat.maxSeasFt} suffix="ft" onChange={(v) => boat.setRule({ maxSeasFt: num(v, boat.maxSeasFt) })} />
          <Field label="Min period" value={boat.minPeriodS} suffix="s" onChange={(v) => boat.setRule({ minPeriodS: num(v, boat.minPeriodS) })} />
          <Field label="Max wind" value={boat.maxWindMph} suffix="mph" onChange={(v) => boat.setRule({ maxWindMph: num(v, boat.maxWindMph) })} />
        </div>
        <div className="mt-2 grid grid-cols-3 gap-2">
          <Field label="Draft" value={boat.draftFt} suffix="ft" onChange={(v) => boat.setRule({ draftFt: num(v, boat.draftFt) })} />
          <Field label="Reserve" value={boat.reservePct} suffix="%" onChange={(v) => boat.setRule({ reservePct: num(v, boat.reservePct) })} />
          <button
            type="button"
            className="mt-4 h-12 rounded-md bg-surface-2 px-2 text-xs font-medium text-fg"
            onClick={() => boat.applySportsman262()}
          >
            Reset 262 preset
          </button>
        </div>
      </section>

      <section
        className={cn(
          "rounded-xl border p-4",
          offshore.home ? "border-good" : "border-poor",
        )}
      >
        <p className="text-xs font-medium tracking-wide text-subtle uppercase">40 nm out · 80 nm RT</p>
        <p className="mt-1 font-display text-2xl leading-tight text-fg">
          {offshore.nm.toFixed(0)} nm · {offshore.hours.toFixed(1)} hr · {offshore.gallons.toFixed(0)} gal
        </p>
        <p className="mt-1 text-sm text-muted">
          40 out / {offshore.nm.toFixed(0)} RT · Twin cruise {boat.cruiseKt} kt · {boat.burnGph} gph · tank {boat.tankGal} gal · {boat.reservePct}% reserve ({offshore.reserveGal.toFixed(0)} gal)
        </p>
        <p className={cn("mt-2 text-sm font-medium", offshore.home ? "text-good" : "text-poor")}>
          {offshore.home
            ? `Fuel covers the round trip with ${Math.max(0, offshore.usable - offshore.gallons).toFixed(0)} gal spare after reserve.`
            : `Short ${ (offshore.gallons - offshore.usable).toFixed(0) } gal after reserve — top off or shorten the run.`}
        </p>
        {!offshore.home ? (
          <p className="mt-3 rounded-lg bg-poor/20 px-3 py-2 text-sm font-medium text-poor" role="status">
            GO HOME — planned burn exceeds usable fuel. Turn around before the bar if the tank is lower than planned.
          </p>
        ) : (
          <p className="mt-3 rounded-lg bg-good/15 px-3 py-2 text-sm text-good" role="status">
            Go-home reserve is built in. Still leave early if weather or burn climbs.
          </p>
        )}
      </section>

      <Fold title="Pre-launch checklist" meta={`${checksDone}/${CHECKLIST_ITEMS.length}`} defaultOpen>
        <ul className="mt-1 flex flex-col gap-1">
          {CHECKLIST_ITEMS.map((item) => (
            <li key={item.id}>
              <label className="flex min-h-12 cursor-pointer items-center gap-3 rounded-md px-2 hover:bg-surface-2">
                <input
                  type="checkbox"
                  className="size-5 accent-[var(--color-accent)]"
                  checked={!!boat.checklist[item.id]}
                  onChange={() => boat.toggleCheck(item.id)}
                />
                <span className={cn("text-sm", boat.checklist[item.id] ? "text-muted line-through" : "text-fg")}>
                  {item.label}
                </span>
              </label>
            </li>
          ))}
        </ul>
        <button type="button" className="mt-2 h-12 rounded-md bg-surface-2 px-3 text-sm text-fg" onClick={() => boat.resetChecklist()}>
          Reset checklist
        </button>
      </Fold>

      <Fold
        title="NWS coastal waters"
        meta={
          briefStale
            ? `Stale · ${briefAge ?? "cached"}`
            : displayBrief
              ? "Official · AMZ158"
              : brief.isError
                ? "Offline"
                : "Official · AMZ158"
        }
        defaultOpen
      >
        {briefStale ? (
          <p className="mb-2 inline-flex rounded-md bg-fair/20 px-2 py-1 text-xs font-medium text-fair" role="status">
            Last-good brief · {briefAge} · live NWS did not load
          </p>
        ) : null}
        {displayBrief?.forecast ? (
          <pre className="mt-1 max-h-48 overflow-auto rounded-lg bg-surface-2 p-3 text-sm leading-snug whitespace-pre-wrap text-fg">
            {displayBrief.forecast}
          </pre>
        ) : (
          <p className="mt-1 text-sm text-muted">
            {brief.isError ? "Forecast didn't load and no cached brief is on this phone." : "Reading the coastal waters forecast…"}
          </p>
        )}
      </Fold>

      <Fold title="Route and fuel" meta={boat.waypoints.length >= 2 ? `${route.nm.toFixed(1)} nm` : "No marks"}>
        <p className="mt-1 text-sm text-muted">
          Straight lines between marks you drop. There is no depth auto-route. A wrong one would put you on a shoal.
        </p>
        <div className="mt-3 grid grid-cols-3 gap-2">
          <Field label="Cruise" value={boat.cruiseKt} suffix="kt" onChange={(v) => boat.setRule({ cruiseKt: num(v, boat.cruiseKt) })} />
          <Field label="Burn" value={boat.burnGph} suffix="gph" onChange={(v) => boat.setRule({ burnGph: num(v, boat.burnGph) })} />
          <Field label="Tank" value={boat.tankGal} suffix="gal" onChange={(v) => boat.setRule({ tankGal: num(v, boat.tankGal) })} />
        </div>
        <p className="mt-3 text-sm text-fg">
          {boat.waypoints.length < 2
            ? "Drop at least two marks on the chart."
            : `${route.nm.toFixed(1)} nm · ${route.hours.toFixed(1)} hr round trip · ${route.gallons.toFixed(1)} gal`}
        </p>
        {boat.waypoints.length >= 2 ? (
          <p className={cn("text-sm font-medium", route.home ? "text-good" : "text-poor")}>
            {route.home ? "Fuel covers the round trip with reserve." : "Round trip is over the usable fuel."}
          </p>
        ) : null}
        <div className="mt-3 flex flex-wrap gap-2">
          <button type="button" className={cn("h-12 rounded-md px-3 text-sm font-medium", boat.markMode ? "bg-accent text-accent-fg" : "bg-surface-2 text-fg")} onClick={() => boat.toggleMark()}>
            {boat.markMode ? "Dropping marks" : "Drop marks"}
          </button>
          <button type="button" className="h-12 rounded-md bg-surface-2 px-3 text-sm text-fg" onClick={() => boat.clearWaypoints()}>
            Clear marks
          </button>
          <button
            type="button"
            className={cn("h-12 rounded-md px-3 text-sm font-medium", boat.recording ? "bg-poor text-bg" : "bg-surface-2 text-fg")}
            onClick={() => boat.setRecording(!boat.recording)}
          >
            {boat.recording ? "Stop track" : "Record track"}
          </button>
          <button type="button" className="h-12 rounded-md bg-surface-2 px-3 text-sm text-fg" onClick={() => boat.clearTrack()}>
            Clear track
          </button>
        </div>
        {boat.waypoints.length ? (
          <ul className="mt-2 text-sm text-muted">
            {boat.waypoints.map((mark) => (
              <li key={mark.id}>
                {mark.name} · {mark.lat.toFixed(3)}, {mark.lng.toFixed(3)}
              </li>
            ))}
          </ul>
        ) : null}
      </Fold>

      <Fold title="NC DMF, live" meta="Proclamations">
        <div className="flex items-baseline justify-between gap-3">
          <p className="text-sm text-muted">Titles from the DMF page. Open the PDF for the limit. This is not a copied size table.</p>
          <a className="inline-flex h-12 shrink-0 items-center text-sm text-accent underline" href={DMF_PAGE}>
            Official page
          </a>
        </div>
        <ul className="mt-2 flex flex-col gap-3">
          {(displayBrief?.proclamations ?? []).map((item) => (
            <li key={item.id}>
              <a className="inline-flex min-h-12 items-center text-sm font-medium text-fg underline" href={item.href}>
                {item.id}
              </a>
              <p className="text-sm text-muted">{item.title}</p>
              <p className="text-sm text-subtle">
                Issued {item.issued} · {item.effective}
              </p>
            </li>
          ))}
          {(displayBrief?.closures ?? []).map((item) => (
            <li key={item.id}>
              <a className="inline-flex min-h-12 items-center text-sm font-medium text-fg underline" href={item.href}>
                {item.id} · shellfish
              </a>
              <p className="text-sm text-muted">{item.summary}</p>
              <p className="text-sm text-subtle">
                {item.counties} · {item.effective}
              </p>
            </li>
          ))}
        </ul>
        {displayBrief?.errors.length ? <p className="mt-2 text-sm text-fair">{displayBrief.errors.join(" ")}</p> : null}
      </Fold>

      <Fold title="Catch log" meta={boat.catches.length ? `${boat.catches.length}` : "Empty"}>
        <form
          className="mt-1 flex gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            const speciesName = species.trim();
            if (!speciesName) return;
            const mark = boat.track[boat.track.length - 1];
            boat.addCatch({
              species: speciesName,
              at: new Date().toISOString(),
              lat: mark?.lat ?? INLET.lat,
              lng: mark?.lng ?? INLET.lng,
              tide: flow ? flow.stage : "tide unknown",
              moon: moonInfo(new Date()).name,
            });
          }}
        >
          <input
            value={species}
            onChange={(event) => setSpecies(event.target.value)}
            className="h-12 min-w-0 flex-1 rounded-md border border-line bg-bg px-3 text-sm text-fg"
            aria-label="Species"
          />
          <button type="submit" className="h-12 rounded-md bg-accent px-3 text-sm font-medium text-accent-fg">
            Log
          </button>
        </form>
        <ul className="mt-2 flex flex-col gap-1 text-sm text-muted">
          {boat.catches.map((entry) => (
            <li key={entry.id}>
              {entry.species} · {entry.tide} · {clock(new Date(entry.at))}
            </li>
          ))}
        </ul>
      </Fold>
    </div>
  );
}

function Field({
  label,
  value,
  suffix,
  onChange,
}: {
  label: string;
  value: number;
  suffix: string;
  onChange: (value: string) => void;
}) {
  return (
    <label className="text-xs text-subtle">
      {label}
      <span className="mt-1 flex items-center gap-1 rounded-md border border-line bg-bg px-2">
        <input
          inputMode="decimal"
          defaultValue={value}
          key={value}
          onBlur={(event) => onChange(event.target.value)}
          className="h-12 w-full bg-transparent text-sm text-fg outline-none"
          aria-label={label}
        />
        <span>{suffix}</span>
      </span>
    </label>
  );
}
